package com.cg.ams.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.ams.bean.AssetAllocationBean;
import com.cg.ams.bean.AssetsBean;
import com.cg.ams.exception.AMSException;
import com.cg.ams.exception.AMSExceptionList;
import com.cg.ams.utility.JdbcUtility;

public class AssetDaoImpl implements IAssetDao {
	static Logger logger = Logger.getLogger(AssetDaoImpl.class);
	Connection connection = null;
	PreparedStatement preparedstatement = null;
	ResultSet resultSet = null;

	@Override
	public String getuserType(String userName, String password)
			throws AMSException {
		connection = JdbcUtility.getConnection();
		logger.info("Connection Established");
		String userType = null;
		try {
			preparedstatement = connection
					.prepareStatement(QueryConstants.Query1);
			preparedstatement.setString(1, userName);
			preparedstatement.setString(2, password);
			ResultSet resultSet = preparedstatement.executeQuery();
			if (resultSet.next()) {
				userType = resultSet.getString(1);

			} else {
				userType = "Invalid Credintials or Username Does not exists";
			}
		} catch (SQLException e) {
			logger.error("Statement Not created");
			throw new AMSException("statement not created" +e);
		}finally {
			JdbcUtility.closeConnection();
		}


		return userType;
	}

	@Override
	public int allocateAsset(int empId, String assetname) throws AMSException {

		connection = JdbcUtility.getConnection();
		logger.info("Connection Established");

		int result = 0;
		try {
			preparedstatement = connection
					.prepareStatement(QueryConstants.Query2);
			preparedstatement.setString(1, assetname);
			preparedstatement.setInt(2, empId);
			preparedstatement.executeUpdate();

			preparedstatement = connection
					.prepareStatement(QueryConstants.Query3);
			resultSet = preparedstatement.executeQuery();

			resultSet.next();

			result = resultSet.getInt(1);

		} catch (SQLException e) {
			logger.error("Statement Not created");
			throw new AMSException(AMSExceptionList.Error6);
		}finally {
			JdbcUtility.closeConnection();
		}

		return result;
	}

	@Override
	public int deallocateAsset(int empId1, String assetname1)
			throws AMSException {

		connection = JdbcUtility.getConnection();
		logger.info("Connection Established");
		int result1 = 0;
		try {
			preparedstatement = connection
					.prepareStatement(QueryConstants.Query4);
			preparedstatement.setString(1, assetname1);
			preparedstatement.setInt(2, empId1);
			preparedstatement.executeUpdate();
			preparedstatement = connection
					.prepareStatement(QueryConstants.Query5);
			resultSet = preparedstatement.executeQuery();

			resultSet.next();

			result1 = resultSet.getInt(1);
		} catch (SQLException e) {
			logger.error("Statement Not created");
			throw new AMSException(AMSExceptionList.Error6);
		}finally {
			JdbcUtility.closeConnection();
		}

		return result1;
	}

	@Override
	public int insertDetails(AssetsBean assetbean) throws AMSException {

		connection = JdbcUtility.getConnection();
		logger.info("Connection Established");
		int insert = 0;
		try {
			preparedstatement = connection
					.prepareStatement(QueryConstants.Query6);
			preparedstatement.setInt(1, assetbean.getAssetId());
			preparedstatement.setString(2, assetbean.getAssetName());
			preparedstatement.setInt(3, assetbean.getQuantity());
			insert = preparedstatement.executeUpdate();
		} catch (SQLException e) {
			logger.error("Statement Not created");
			throw new AMSException(AMSExceptionList.Error6);
		}finally {
			JdbcUtility.closeConnection();
		}

		return insert;
	}

	@Override
	public List<AssetAllocationBean> viewRequest() throws AMSException {

		connection = JdbcUtility.getConnection();
		logger.info("Connection Established");
		List<AssetAllocationBean> list = new ArrayList<AssetAllocationBean>();
		try {
			preparedstatement = connection
					.prepareStatement(QueryConstants.Query7);
			resultSet = preparedstatement.executeQuery();
			while (resultSet.next()) {
				int allocationId = resultSet.getInt(1);
				String assetName = resultSet.getString(2);
				int empNo = resultSet.getInt(3);
				String status = resultSet.getString(4);
				AssetAllocationBean allocationBean = new AssetAllocationBean(
						allocationId, assetName, empNo, status);
				list.add(allocationBean);
			}
		} catch (SQLException e) {
			logger.error("Statement Not created");
			throw new AMSException(AMSExceptionList.Error6);
		}finally {
			JdbcUtility.closeConnection();
		}

		return list;
	}

	@Override
	public int approve(AssetAllocationBean assetallocation) throws AMSException {

		connection = JdbcUtility.getConnection();
		logger.info("Connection Established");
		int update = 0;
		try {
			preparedstatement = connection
					.prepareStatement(QueryConstants.Query8);
			preparedstatement.setInt(2, assetallocation.getEmpNo());

			update = preparedstatement.executeUpdate();
		} catch (SQLException e) {
			logger.error("Statement Not created");
			throw new AMSException(AMSExceptionList.Error6);
		}finally {
			JdbcUtility.closeConnection();
		}
		return update;
	}

	@Override
	public int viewQuantity(String assetName) throws AMSException {
		connection = JdbcUtility.getConnection();
		logger.info("Connection Established");
		int quantity = 0;
		try {
			preparedstatement = connection
					.prepareStatement(QueryConstants.Query9);
			preparedstatement.setString(1, assetName);
			resultSet = preparedstatement.executeQuery();
			if (resultSet.next()) {
				quantity = resultSet.getInt(1);

			}
		} catch (SQLException e) {
			logger.error("Statement Not created");
			throw new AMSException(AMSExceptionList.Error6);
		}finally {
			JdbcUtility.closeConnection();
		}

		return quantity;
	}

	@Override
	public int decrementQuantity(String assetName) throws AMSException {

		connection = JdbcUtility.getConnection();
		logger.info("Connection Established");
		int decrease = 0;
		try {
			preparedstatement = connection
					.prepareStatement(QueryConstants.Query10);
			preparedstatement.setString(1, assetName);
			decrease = preparedstatement.executeUpdate();
		} catch (SQLException e) {
			logger.error("Statement Not created");
			throw new AMSException(AMSExceptionList.Error6);
		}finally {
			JdbcUtility.closeConnection();
		}

		return decrease;
	}

	@Override
	public int increase(String assetName) throws AMSException {

		connection = JdbcUtility.getConnection();
		logger.info("Connection Established");
		int delete = 0;
		try {
			preparedstatement = connection
					.prepareStatement(QueryConstants.Query11);
			preparedstatement.setString(1, assetName);
			delete = preparedstatement.executeUpdate();
			System.out.println("111111" + delete);
		} catch (SQLException e) {
			logger.error("Statement Not created");
			throw new AMSException(AMSExceptionList.Error6);
		}finally {
			JdbcUtility.closeConnection();
		}

		return delete;
	}

	@Override
	public int incrementQuantity(String assetName) throws AMSException {
		connection = JdbcUtility.getConnection();
		logger.info("Connection Established");
		int increase = 0;
		try {
			preparedstatement = connection
					.prepareStatement(QueryConstants.Query12);
			preparedstatement.setString(1, assetName);
			increase = preparedstatement.executeUpdate();
		} catch (SQLException e) {
			logger.error("Statement Not created");
			throw new AMSException(AMSExceptionList.Error6);
		}finally {
			JdbcUtility.closeConnection();
		}
		return increase;
	}

	@Override
	public int deleteRequest(int empNo) throws AMSException {

		connection = JdbcUtility.getConnection();
		logger.info("Connection Established");
		int update = 0;
		try {
			preparedstatement = connection
					.prepareStatement(QueryConstants.Query13);
			preparedstatement.setInt(1, empNo);
			update = preparedstatement.executeUpdate();
		} catch (SQLException e) {
			logger.error("Statement Not created");
			throw new AMSException(AMSExceptionList.Error6);
		}finally {
			JdbcUtility.closeConnection();
		}

		return update;
	}

	@Override
	public int validAsset(String assetname) throws AMSException {
		connection = JdbcUtility.getConnection();
		logger.info("Connection Established");
		int quantity = 0;
		try {
			preparedstatement = connection
					.prepareStatement(QueryConstants.Query14);
			preparedstatement.setString(1, assetname);
			resultSet = preparedstatement.executeQuery();
			if (resultSet.next()) {
				quantity = resultSet.getInt(1);
			}
		} catch (SQLException e) {
			logger.error("Statement Not created");
			throw new AMSException(AMSExceptionList.Error6);
		}finally {
			JdbcUtility.closeConnection();
		}

		return quantity;
	}

	@Override
	public int updateAsset(AssetsBean assetbean) throws AMSException {

		connection = JdbcUtility.getConnection();
		logger.info("Connection Established");
		int update = 0;
		try {
			preparedstatement = connection
					.prepareStatement(QueryConstants.Query15);
			preparedstatement.setInt(1, assetbean.getQuantity());
			preparedstatement.setString(2, assetbean.getAssetName());
			update = preparedstatement.executeUpdate();
		} catch (SQLException e) {
			logger.error("Statement Not created");
			throw new AMSException(AMSExceptionList.Error6);
		}finally {
			JdbcUtility.closeConnection();
		}

		return update;
	}

	/*
	 * @Override public int approve(String assetName,int empNo) throws
	 * AMSException { AssetAllocationBean allocation=new AssetAllocationBean()
	 * connection=JdbcUtility.getConnection(); int update=0; try {
	 * preparedstatement=connection.prepareStatement(QueryConstants.Query8);
	 * preparedstatement.setString(1, allocation.getAssetName());
	 * preparedstatement.setInt(2, allocation.getEmpNo());
	 * update=preparedstatement.executeUpdate(); System.out.println(update); }
	 * catch (SQLException e) { // TODO Auto-generated catch block
	 * e.printStackTrace(); }
	 * 
	 * return update; }
	 */

}
