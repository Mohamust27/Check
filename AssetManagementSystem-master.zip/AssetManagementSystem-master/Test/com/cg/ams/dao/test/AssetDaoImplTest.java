package com.cg.ams.dao.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.cg.ams.bean.AssetAllocationBean;
import com.cg.ams.bean.AssetsBean;
import com.cg.ams.bean.UserMasterBean;
import com.cg.ams.dao.AssetDaoImpl;
import com.cg.ams.exception.AMSException;

public class AssetDaoImplTest {
 static AssetDaoImpl asset=null;
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		asset=new AssetDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		
	}

	@Test
	public void testGetuserType() {
		UserMasterBean userType=new UserMasterBean("1","abc","123","manager");
		try{
			String result=asset.getuserType("abc","123");
			assertEquals("manager", result);
		}catch(AMSException e){
		e.printStackTrace();
		}
		
		UserMasterBean userType1=new UserMasterBean("2","xyz","123","admin");
		try{
			String result=asset.getuserType("xyz","123");
			assertEquals("admin", result);
		}catch(AMSException e){
		e.printStackTrace();
		}
	}

	@Test
	public void testAllocateAsset() {
		AssetAllocationBean allocationBean=new AssetAllocationBean(200,"monitor",100,"available");
		try{
			int result=asset.allocateAsset(200,"monitor");
			assertEquals(1, result);
		}catch(AMSException e){
		e.printStackTrace();
		}
		
	}

	@Test
	public void testDeallocateAsset() {
		AssetAllocationBean allocationBean=new AssetAllocationBean(200,"monitor",100,"available");
		try{
			int result=asset.deallocateAsset(200,"monitor");
			assertEquals(1, result);
		}catch(AMSException e){
		e.printStackTrace();
		}
		
		
	}

	@Test
	public void testInsertDetails() {
		AssetsBean assetBean=new AssetsBean(1,"monitor",4);
		try{
			int result=asset.deallocateAsset(200,"monitor");
			assertEquals(1, result);
		}catch(AMSException e){
		e.printStackTrace();
		}
		
		
	}

	/*@Test
	public void testViewRequest(){
		AssetAllocationBean allocationBean=new AssetAllocationBean(200,"monitor",100,"available");
		try{
			int result=asset.viewRequest();
			assertEquals(1, result);
		}catch(AMSException e){
		e.printStackTrace();
		}
		
		
	}*/
		
	

	@Test
	public void testApprove() {
	
		
AssetAllocationBean allocationBean=new AssetAllocationBean(200,"monitor",100,"available");

try{
	List<AssetAllocationBean> result=asset.viewRequest();
	assertEquals(1,result);
}catch(AMSException e){
e.printStackTrace();
}
	}
	
	

	@Test
	public void testViewQuantity() throws AMSException {
		AssetsBean assetBean=new AssetsBean(1,"monitor",4);
		int result=asset.viewQuantity("monitor");
		assertTrue("monitor", true);
		
	}

	@Test
	public void testDecrementQuantity() throws AMSException {
		AssetsBean assetBean=new AssetsBean(1,"monitor",4);
		int result=asset.decrementQuantity("monitor");
		assertEquals(4,result);
	}

	@Test
	public void testIncrease() {
	
	}

	@Test
	public void testIncrementQuantity() {
	
	}

	@Test
	public void testDeleteRequest() {
		
	}

	@Test
	public void testValidAsset() {
	
	}

	/*@Test
	public void testUpdateAsset() {
		AssetsBean assetBean=new AssetsBean(1,"monitor",4);
		try{
			int result=asset.updateAsset(assetBean);
			assertEquals(3, result);
		}catch(AMSException e){
		e.printStackTrace();
		}
	}*/

	
}
